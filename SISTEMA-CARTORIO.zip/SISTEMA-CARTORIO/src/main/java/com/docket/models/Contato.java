package com.docket.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name="contato")
public class Contato {
	
	@Id
	@Column(unique = true, nullable = true)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int id;
	
	@Column(name = "Numero_Contato", nullable = true)
	private String numContato;

	@Autowired
	public Contato(int id, String numContato) {
		this.id = id;
		this.numContato = numContato;
	}
	
	public Contato() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNumContato() {
		return numContato;
	}

	public void setNumContato(String numContato) {
		this.numContato = numContato;
	}
}
