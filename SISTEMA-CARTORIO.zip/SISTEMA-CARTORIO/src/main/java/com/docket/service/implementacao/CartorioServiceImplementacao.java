package com.docket.service.implementacao;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.docket.models.Cartorio;
import com.docket.repository.CartorioRepository;
import com.docket.service.CartorioService;

@Service
public class CartorioServiceImplementacao implements CartorioService{

	@Autowired
	private CartorioRepository cartorioRepository;
	
	@Autowired
	public CartorioServiceImplementacao(CartorioRepository cartorioRepository) {
		this.cartorioRepository = cartorioRepository;
	}

	// CADASTRA CARTÓRIO 
	
	@Override
	public Cartorio cadastroCartorio(Cartorio cartorio) {
		this.cartorioRepository.save(cartorio);
		return cartorio;
	}
	
	// LISTA CARTÓRIO 

	@Override
	public List<Cartorio> listaCartorio() {

		List<Cartorio> listaCartorio = this.cartorioRepository.findAll();
		
		if (listaCartorio.equals(null)) {
			System.err.println("Nenhum cartório registrado.");
		}
		
		return listaCartorio;
	}
	
	// BUSCA CARTÓRIO POR ID

	@Override
	public Optional<Cartorio> buscaCartorioByID(Integer id) {
		Optional<Cartorio> cartorio = cartorioRepository.findById(id);
		
		if(cartorio.equals(null))
			System.out.println("Cartório com o ID: " + id + " nao encontrado!");
		
			return cartorio;
	}
	
	// EDITA CARTÓRIO POR ID
	
	@Override
	public Cartorio editaCartorio(Cartorio c, Integer id) {
		
		try {
			
			this.cartorioRepository.findById(c.getId()).get();
			this.cartorioRepository.save(c);
		
        } catch (NoSuchElementException noSuchElementException) {
            System.err.println("Nenhum cartório encontrada para o ID.");;
        }
		
		return c;
	}
	
	// DELETA CARTÓRIO POR ID

	@Override
	public Cartorio deleteCartorio(Integer id) {
		Optional<Cartorio> cartorio = cartorioRepository.findById(id);
		
		if(cartorio.equals(null)) {
			System.out.println("Cartório com o ID: " + id + " nao encontrado!");
		
		} else {
			
			cartorioRepository.deleteById(id);
		}
		
		return cartorio.get();
	}

}
