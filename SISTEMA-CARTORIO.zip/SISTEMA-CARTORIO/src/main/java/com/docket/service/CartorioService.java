package com.docket.service;

import java.util.List;
import java.util.Optional;

import com.docket.models.Cartorio;

/**
 * Interface com os métodos referentes a Cartorio.
 * 
 * @author Phaola Oliveira
 */

public interface CartorioService {
	
	Cartorio cadastroCartorio(Cartorio cartorio);

	List<Cartorio> listaCartorio();

	Optional<Cartorio> buscaCartorioByID(Integer id);

	Cartorio editaCartorio(Cartorio cartorio, Integer id);

	Cartorio deleteCartorio(Integer id);

}
