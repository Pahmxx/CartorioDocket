package com.docket.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.docket.models.Cartorio;
import com.docket.response.Response;
import com.docket.service.CartorioService;

/**
 * @author Phaola Oliveira
 */

@RestController
@RequestMapping(path = "/cartorio")
public class CartorioController {
	
	@Autowired
	private CartorioService cartorioService;

	@Autowired
	public CartorioController(CartorioService cartorioService) {
		this.cartorioService = cartorioService;
	}
	
	@PostMapping("/cadastra")
	public ResponseEntity<Response<Cartorio>> cadastrar(@Valid @RequestBody Cartorio c, BindingResult resultado) {
		
		// Caso tenha algum erro na validação.
		if (resultado.hasErrors()) {
			List<String> erros = new ArrayList<String>();
			
			// Percorre a lista de erros.
			resultado.getAllErrors().forEach(erro -> erros.add(erro.getDefaultMessage()));
			
			// Retorna bad request informando os erros.
			return ResponseEntity.badRequest().body(new Response<Cartorio>(erros));
		}
        
		// Efetua o cadastro.
		return ResponseEntity.ok(new Response<Cartorio>(this.cartorioService.cadastroCartorio(c)));
	}
	
	@GetMapping("/lista")
	public ResponseEntity<Response<List<Cartorio>>> lista() {
		return ResponseEntity.ok(new Response<List<Cartorio>>(this.cartorioService.listaCartorio()));
	}
	
	
	@GetMapping("/busca/{id}")
	public ResponseEntity<?> buscaCartorioById(@PathVariable(value = "id") Integer id) {

		Optional<Cartorio> cartorio  = cartorioService.buscaCartorioByID(id);

		if (cartorio.isPresent()){
			return ResponseEntity.ok(cartorio);

		} else {
			return null;
		}
	}
	
	@PutMapping("/edita/{id}")
	public ResponseEntity<Response<Cartorio>> atualizar(@PathVariable(name="id") int id, @Valid @RequestBody Cartorio c, BindingResult resultado) {
		
		// Caso tenha algum erro na validação.
		if (resultado.hasErrors()) {
			List<String> erros = new ArrayList<String>();
			
			// Percorre a lista de erros.
			resultado.getAllErrors().forEach(erro -> erros.add(erro.getDefaultMessage()));
			
			// Retorna bad request informando os erros.
			return ResponseEntity.badRequest().body(new Response<Cartorio>(c));
		}
		
		c.setId(id);
		this.cartorioService.editaCartorio(c, id);
		return ResponseEntity.ok(new Response<>(this.cartorioService.editaCartorio(c, id)));
	}
	
	@DeleteMapping("/deletar/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public ResponseEntity<?> DeleteCartorio(@PathVariable(value = "id") Integer id) {	
		
			Cartorio cartorioDeletado = cartorioService.deleteCartorio(id);
			return ResponseEntity.ok("Cartorio com o seguinte ID: " + cartorioDeletado.getId() + ", excluído com sucesso!");
	}
	
}
