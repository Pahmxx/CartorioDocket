package com.docket.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartorioApp {

	public static void main(String[] args) {
		SpringApplication.run(CartorioApp.class, args);
	}

}
