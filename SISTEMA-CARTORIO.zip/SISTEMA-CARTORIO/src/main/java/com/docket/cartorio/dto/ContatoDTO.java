package com.docket.cartorio.dto;

import com.docket.models.Contato;

public class ContatoDTO {

	private int id;
	private String numContato;
	
	public ContatoDTO() {
	}

	public ContatoDTO(Contato c) {
		this.id = c.getId();
		this.numContato = c.getNumContato();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNumContato() {
		return numContato;
	}

	public void setNumContato(String numContato) {
		this.numContato = numContato;
	}
	
	public Contato conveter() {
		return new Contato(this.id, this.numContato);
	}
}
