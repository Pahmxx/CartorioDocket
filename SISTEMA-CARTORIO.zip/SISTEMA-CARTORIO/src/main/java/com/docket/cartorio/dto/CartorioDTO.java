package com.docket.cartorio.dto;

import java.util.Date;

import com.docket.models.Cartorio;

public class CartorioDTO {
	
	private int id;
	private String nomeCartorio;
	private Date dataCadastro;	

	public CartorioDTO() {
	}

	public CartorioDTO(Cartorio c) {
		this.id = c.getId();
		this.nomeCartorio = c.getNomeCartorio();
		this.dataCadastro = c.getDataCadastro();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNomeCartorio() {
		return nomeCartorio;
	}

	public void setNomeCartorio(String nomeCartorio) {
		this.nomeCartorio = nomeCartorio;
	}

	public Date getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	
	public Cartorio conveter() {
		return new Cartorio(id, this.nomeCartorio, this.dataCadastro);
	}
}
