package com.docket.cartorio.dto;

import com.docket.models.Certidao;

public class CertidaoDTO {

	private int idCertidao;
	private String tipoCertidao;
	
	public CertidaoDTO() {
	}

	public CertidaoDTO(Certidao c) {
		this.idCertidao = c.getIdCertidao();
		this.tipoCertidao = c.getTipoCertidao();
	}

	public int getIdCertidao() {
		return idCertidao;
	}

	public void setIdCertidao(int idCertidao) {
		this.idCertidao = idCertidao;
	}

	public String getTipoCertidao() {
		return tipoCertidao;
	}

	public void setTipoCertidao(String tipoCertidao) {
		this.tipoCertidao = tipoCertidao;
	}
	
	public Certidao conveter() {
		return new Certidao(idCertidao, this.tipoCertidao);
	}
	
}
