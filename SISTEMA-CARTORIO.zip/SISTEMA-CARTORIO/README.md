# Sistema Cartório - gerenciamento

Java, frameworks SPRING BOOT, API RESTFUL, JPA, HIBERNATE, H2, Arquitetura MVC.

*API- POSTMAN PARA TESTES *

https://www.getpostman.com/collections/46c47546a5f19b95b960
